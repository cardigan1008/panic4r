Data for various benchmarks. All in public domain or otherwise freely
licensed.
