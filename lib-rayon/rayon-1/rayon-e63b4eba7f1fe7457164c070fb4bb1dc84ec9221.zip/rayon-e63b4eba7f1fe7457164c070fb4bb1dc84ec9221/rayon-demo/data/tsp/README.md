Inputs for the Traveling Salesman Problem solver. These are in TSPLIB
format.

Sources:

- `dj15.tsp`: derived from `dj38.tsp`
- `dj38.tsp`: <https://www.math.uwaterloo.ca/tsp/world/dj38.tsp>

