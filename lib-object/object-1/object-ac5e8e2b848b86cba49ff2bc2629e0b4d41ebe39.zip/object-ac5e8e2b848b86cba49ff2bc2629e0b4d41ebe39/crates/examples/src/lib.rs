// Style.
#![allow(clippy::single_match)]

#[cfg(feature = "read")]
pub mod objdump;

#[cfg(feature = "read")]
pub mod readobj;
