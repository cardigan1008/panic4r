*Jump to [source](multicall-hostname.rs)*

Example of a `hostname-style` multicall program

See the documentation for `clap::Command::multicall` for rationale.

This example omits the implementation of displaying address config

```console
$ hostname
www

```
*Note: without the links setup, we can't demonstrate the multicall behavior*
