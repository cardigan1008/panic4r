use clap::Subcommand;

#[derive(Subcommand, Debug)]
struct Opt {}

fn main() {}
