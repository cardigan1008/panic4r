mod bash;
mod common;
mod dynamic;
mod elvish;
mod fish;
mod general;
mod powershell;
mod zsh;
