# How to Contribute

See the [clap-wide CONTRIBUTING.md](../CONTRIBUTING.md).  This will contain `clap_lex` specific notes.
