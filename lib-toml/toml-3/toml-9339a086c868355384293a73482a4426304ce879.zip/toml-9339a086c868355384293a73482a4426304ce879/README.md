This repo contains:
- [`toml` crate](./crates/toml) for serde support
- [`toml_edit` crate](./crates/toml_edit) for format-preserving editing of TOML
- [`toml_datetime` crate](./crates/toml_datetime) for a common type definition between `toml` and `toml_edit`
