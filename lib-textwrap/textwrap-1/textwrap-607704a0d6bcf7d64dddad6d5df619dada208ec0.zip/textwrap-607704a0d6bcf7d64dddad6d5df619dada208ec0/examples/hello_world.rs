fn main() {
    let text = "Hello, welcome to a world of beautifully wrapped text!";
    println!("{}", textwrap::fill(text, 30));
}
