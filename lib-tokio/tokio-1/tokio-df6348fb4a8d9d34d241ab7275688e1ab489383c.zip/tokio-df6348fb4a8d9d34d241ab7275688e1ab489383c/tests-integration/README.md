Tests that require additional components than just the `tokio` crate.
