#[cfg(feature = "full")]
doc_comment::doc_comment!(include_str!("../../README.md"));
