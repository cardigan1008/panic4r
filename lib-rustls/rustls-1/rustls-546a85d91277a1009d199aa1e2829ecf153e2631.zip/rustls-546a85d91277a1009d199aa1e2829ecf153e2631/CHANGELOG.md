# Changelog

The detailed list of changes in each release can be found at
https://github.com/rustls/rustls/releases.
