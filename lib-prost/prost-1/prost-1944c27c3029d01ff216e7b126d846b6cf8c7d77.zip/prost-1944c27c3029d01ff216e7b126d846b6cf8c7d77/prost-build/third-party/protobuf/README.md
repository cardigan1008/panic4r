`LICENSE` was taken from https://github.com/google/protobuf/archive/v3.7.1.zip.

The `protoc-*` and `protoc-*.exe` binaries here were taken from:

* https://github.com/google/protobuf/releases/download/v3.7.1/protoc-3.7.1-linux-aarch_64.zip
* https://github.com/google/protobuf/releases/download/v3.7.1/protoc-3.7.1-linux-x86_32.zip
* https://github.com/google/protobuf/releases/download/v3.7.1/protoc-3.7.1-linux-x86_64.zip
* https://github.com/google/protobuf/releases/download/v3.7.1/protoc-3.7.1-osx-x86_64.zip
* https://github.com/google/protobuf/releases/download/v3.7.1/protoc-3.7.1-win32.zip

The `include` directory's contents were taken from the linux-x86_64 package.
