---
name: Feature request
about: Suggest an idea to Plotter maintainers
title: "[Feature Request]"
labels: feature request
assignees: ''

---

### What is the feature ?
*Detailed feature descrption*

### (Optional) Why this feature is useful and how people would use the feature ?
*Explain why this feature is important*

### (Optional) Additional Information
*More details are appreciated:)*
