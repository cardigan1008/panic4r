## Example usage of Reqwest from WASM

Install wasm-pack with

    npm install

Then you can build the example locally with:


    npm run serve

and then visiting http://localhost:8080 in a browser should run the example!


This example is loosely based off of [this example](https://github.com/rustwasm/wasm-bindgen/blob/master/examples/fetch/src/lib.rs), an example usage of `fetch` from `wasm-bindgen`.