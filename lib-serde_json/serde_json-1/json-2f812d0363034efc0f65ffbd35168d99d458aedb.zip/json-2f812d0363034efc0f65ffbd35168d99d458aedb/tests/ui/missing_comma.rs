use serde_json::json;

fn main() {
    json!({ "1": "" "2": "" });
}
