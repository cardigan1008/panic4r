This directory contains various recordings of results. These are committed to
the repository so that they can be compared over time. (At the time of writing,
there is no tooling for facilitating this comparison. It has to be done
manually.)
