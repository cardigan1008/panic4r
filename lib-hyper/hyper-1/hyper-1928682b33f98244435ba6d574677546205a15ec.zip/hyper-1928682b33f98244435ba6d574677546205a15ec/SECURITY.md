# Security Policy

hyper (and related projects in hyperium) use the same security policy as the [Tokio project][tokio-security].

## Report a security issue

The process for reporting an issue is the same as the [Tokio project][tokio-security]. This includes private reporting via security@tokio.rs.

[tokio-security]: https://github.com/tokio-rs/tokio/security/policy
