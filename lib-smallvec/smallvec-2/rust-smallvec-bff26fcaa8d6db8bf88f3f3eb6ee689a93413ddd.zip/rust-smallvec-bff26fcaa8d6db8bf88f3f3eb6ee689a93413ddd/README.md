rust-smallvec
=============

[Documentation](http://doc.servo.org/smallvec/)

"Small vector" optimization for Rust: store up to a small number of items on the stack
