# Announcing `gimli` $TODO_VERSION

`gimli` is a blazing fast library for consuming the DWARF debugging format.

* [GitHub][]
* [crates.io][]

Upgrade to this release by updating your `Cargo.toml`:

```toml
gimli = "$TODO_VERSION"
```

## Changelog

<insert relevant section of CHANGELOG.md here>

## Friends

Thanks to everyone who contributed to this release!

<insert the output of friends.sh here>

## Contributing

Want to join us? Check out our [CONTRIBUTING.md][contributing] and take a look
at some of these issues:

* [Issues labeled "easy"][easy]

[GitHub]: https://github.com/gimli-rs/gimli
[crates.io]: https://crates.io/crates/gimli
[contributing]: https://github.com/gimli-rs/gimli/blob/master/CONTRIBUTING.md
[easy]: https://github.com/gimli-rs/gimli/issues?q=is%3Aopen+is%3Aissue+label%3Aeasy
