// This is purposely empty. See src/bench.rs instead. We use src/bench.rs
// to avoid including the same file in multiple build targets.
