pub fn unwrap() {
    let x: Option<i32> = None;

    x.unwrap();
}