pub fn mul_assign(mut x: i32) -> i32 {
    x *= 2;
    
    x
}