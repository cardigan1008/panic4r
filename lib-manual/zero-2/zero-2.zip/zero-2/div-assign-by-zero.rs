pub fn div_assign(mut x: i32, y: i32) -> i32 {
    x /= y;

    x
}