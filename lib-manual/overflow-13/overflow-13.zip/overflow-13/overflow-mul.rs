pub mod two;

pub fn mul(x: i32) -> i32 {
    x * two::two()
}
