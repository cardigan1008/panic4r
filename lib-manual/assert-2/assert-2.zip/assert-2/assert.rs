pub fn one() {
    let x = [1, 2, 3, 4];

    assert!(x[0] == 2);
}