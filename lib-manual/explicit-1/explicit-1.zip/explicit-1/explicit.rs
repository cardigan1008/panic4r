pub fn explicit() {
    let x = [1, 2, 3, 4];

    if x[0] != 2 {
        panic!("x[0] is not 2!");
    }
}