pub fn sub(x: i32) -> i32 {
    x - 1
}
