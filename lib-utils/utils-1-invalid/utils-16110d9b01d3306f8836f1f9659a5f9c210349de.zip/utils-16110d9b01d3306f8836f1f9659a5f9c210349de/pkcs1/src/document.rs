//! Serialized DER-encoded documents stored in heap-backed buffers.
// TODO(tarcieri): heapless support?

pub(crate) mod private_key;
pub(crate) mod public_key;
